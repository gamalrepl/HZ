import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

const START_YEAR = 2005;
const END_YEAR = 2106;
const YEARS = Array.from({ length: END_YEAR - START_YEAR + 1 }, (_, i) => START_YEAR + i);
const MONTHS = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];

export default function Home() {
  const [level, setLevel] = useState<1 | 2 | 3>(1);
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);

  const handleYearClick = (year: number) => {
    setSelectedYear(year);
    setLevel(2);
  };

  const handleMonthClick = (month: string) => {
    setSelectedMonth(month);
    setLevel(3);
  };

  const goBackToLevel1 = () => {
    setLevel(1);
    setTimeout(() => { setSelectedYear(null); setSelectedMonth(null); }, 500);
  };

  const goBackToLevel2 = () => {
    setLevel(2);
    setTimeout(() => { setSelectedMonth(null); }, 500);
  };

  const handleBack = () => {
    if (level === 2) goBackToLevel1();
    else if (level === 3) goBackToLevel2();
  };

  return (
    <div className="min-h-screen w-full bg-white text-black font-sans relative overflow-hidden" dir="rtl" data-testid="app-container">

      {/* Back Button — always visible, fixed */}
      <button
        onClick={handleBack}
        disabled={level === 1}
        className={`absolute top-9 left-8 z-50 text-base font-medium tracking-wider transition-all duration-300 ${
          level === 1 ? "text-black/20 cursor-default" : "text-black/60 hover:text-black cursor-pointer"
        }`}
        data-testid="btn-back"
      >
        ← العودة
      </button>

      {/* Main Content */}
      <main className="w-full h-screen flex flex-col justify-center items-center relative">
        <AnimatePresence mode="wait">

          {/* LEVEL 1 — عمري */}
          {level === 1 && (
            <motion.div
              key="level-1"
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="w-full"
              data-testid="level-1-container"
            >
              <TimelineBlock
                label="عمري"
                data-testid="timeline-lifetime"
              >
                <YearDots years={YEARS} onYearClick={handleYearClick} />
              </TimelineBlock>
            </motion.div>
          )}

          {/* LEVEL 2 — السنة المحددة */}
          {level === 2 && selectedYear && (
            <motion.div
              key="level-2"
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="w-full"
              data-testid="level-2-container"
            >
              <TimelineBlock
                label={String(selectedYear)}
                data-testid="timeline-year"
              >
                <MonthDots months={MONTHS} onMonthClick={handleMonthClick} />
              </TimelineBlock>
            </motion.div>
          )}

          {/* LEVEL 3 — الشهر المحدد */}
          {level === 3 && selectedYear && selectedMonth && (
            <motion.div
              key="level-3"
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 16 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="w-full"
              data-testid="level-3-container"
            >
              <div className="w-full relative py-20" data-testid="timeline-month">
                <div className="absolute top-0 right-16 text-2xl font-semibold tracking-widest text-black">
                  {selectedMonth} {selectedYear}
                </div>
                <div className="px-16 pt-4">
                  <CalendarGrid
                    year={selectedYear}
                    monthIndex={MONTHS.indexOf(selectedMonth)}
                  />
                </div>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>
    </div>
  );
}

/* ── Shared Timeline Block ── */
function TimelineBlock({
  label,
  children,
  "data-testid": testId,
}: {
  label: string;
  children: React.ReactNode;
  "data-testid"?: string;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = scrollRef.current.scrollWidth;
    }
  }, [label]);

  return (
    <div className="w-full relative py-20" data-testid={testId}>
      {/* Label — top right, same style for all levels */}
      <div className="absolute top-0 right-16 text-2xl font-semibold tracking-widest text-black">
        {label}
      </div>

      {/* Scrollable timeline */}
      <div
        ref={scrollRef}
        className="w-full overflow-x-auto hide-scrollbar"
        style={{ scrollBehavior: "smooth" }}
      >
        <div className="flex items-start min-w-max relative pl-16 pr-40 pt-4 pb-12">
          {children}
        </div>
      </div>
    </div>
  );
}

/* ── Year Dots ── */
function YearDots({
  years,
  onYearClick,
}: {
  years: number[];
  onYearClick: (year: number) => void;
}) {
  const today = useToday();
  const currentYear = today.getFullYear();

  return (
    <>
      <div className="absolute top-[26px] left-0 right-20 h-[2px] bg-black/40 z-0" />
      <div className="flex items-start gap-16 md:gap-28 z-10">
        {years.map((year) => {
          const isPast    = year < currentYear;
          const isCurrent = year === currentYear;
          return (
            <button
              key={year}
              onClick={() => onYearClick(year)}
              className="flex flex-col items-center group outline-none"
              data-testid={`btn-year-${year}`}
            >
              <div className={`w-5 h-5 rounded-full transition-all duration-300 group-hover:scale-150 ${
                isCurrent
                  ? "bg-black ring-2 ring-offset-2 ring-black"
                  : isPast
                  ? "bg-black"
                  : "border-[1.5px] border-black/40 bg-white"
              }`} />
              <span className={`mt-4 text-base font-medium whitespace-nowrap transition-colors duration-300 ${
                isCurrent
                  ? "font-bold text-black"
                  : isPast
                  ? "text-black/70 group-hover:text-black"
                  : "text-black/30 group-hover:text-black/60"
              }`}>
                {year}
              </span>
            </button>
          );
        })}
      </div>
    </>
  );
}

/* ── useToday: يتحدث تلقائيًا عند منتصف الليل ── */
function useToday() {
  const [today, setToday] = useState(() => new Date());

  useEffect(() => {
    function scheduleNextMidnight() {
      const now = new Date();
      const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      const msUntilMidnight = tomorrow.getTime() - now.getTime();

      const timer = setTimeout(() => {
        setToday(new Date());
        scheduleNextMidnight();
      }, msUntilMidnight);

      return timer;
    }

    const timer = scheduleNextMidnight();
    return () => clearTimeout(timer);
  }, []);

  return today;
}

/* ── Calendar Grid helpers ── */
const WEEKDAYS = ['س', 'ح', 'إ', 'ث', 'ر', 'خ', 'ج']; // السبت→الجمعة
const COL_PX = 72; // عرض كل خانة بالبكسل

function getColIndex(jsDay: number): number {
  // 6(Sat)→0  0(Sun)→1  1(Mon)→2  2(Tue)→3  3(Wed)→4  4(Thu)→5  5(Fri)→6
  return (jsDay + 1) % 7;
}

function buildWeeks(year: number, monthIndex: number): (number | null)[][] {
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
  const startCol = getColIndex(new Date(year, monthIndex, 1).getDay());
  const flat: (number | null)[] = Array(startCol).fill(null);
  for (let d = 1; d <= daysInMonth; d++) flat.push(d);
  const weeks: (number | null)[][] = [];
  for (let i = 0; i < flat.length; i += 7) {
    const week = flat.slice(i, i + 7);
    while (week.length < 7) week.push(null);
    weeks.push(week);
  }
  return weeks;
}

/* ── Calendar Grid ── */
function CalendarGrid({ year, monthIndex }: { year: number; monthIndex: number }) {
  const today = useToday();
  const weeks = buildWeeks(year, monthIndex);

  const isPast = (day: number) => {
    const d = new Date(year, monthIndex, day);
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    return d < todayStart;
  };

  const isToday = (day: number) =>
    year === today.getFullYear() &&
    monthIndex === today.getMonth() &&
    day === today.getDate();

  return (
    <div className="flex flex-col gap-8">
      {/* أسماء الأيام */}
      <div className="flex" style={{ width: 7 * COL_PX }}>
        {WEEKDAYS.map((d) => (
          <div
            key={d}
            className="flex justify-center text-sm font-semibold text-black/30"
            style={{ width: COL_PX }}
          >
            {d}
          </div>
        ))}
      </div>

      {/* صفوف الأسابيع */}
      {weeks.map((week, wi) => {
        const firstCol = week.findIndex((d) => d !== null);
        const lastCol = week.reduce((acc, d, i) => (d !== null ? i : acc), -1);

        // In RTL flex: item i is at physical position (6-i)*COL_PX from the left.
        // Use left+width to avoid direction-aware CSS ambiguity.
        const lineLeft  = (6 - lastCol)  * COL_PX + COL_PX / 2; // center of leftmost dot
        const lineRight = (6 - firstCol) * COL_PX + COL_PX / 2; // center of rightmost dot
        const lineWidth = lineRight - lineLeft;

        return (
          <div key={wi} className="relative flex" style={{ width: 7 * COL_PX }}>
            {/* خط يمتد بين أول وآخر نقطة في الصف */}
            {firstCol !== -1 && lastCol !== -1 && firstCol !== lastCol && (
              <div
                className="absolute top-[10px] h-[2px] bg-black/40 z-0"
                style={{ left: lineLeft, width: lineWidth }}
              />
            )}
            {/* ٧ خانات */}
            {week.map((day, ci) => (
              <div
                key={ci}
                className="flex flex-col items-center z-10 relative"
                style={{ width: COL_PX }}
              >
                {day !== null ? (
                  <>
                    <div
                      className={`w-5 h-5 rounded-full transition-all duration-300 ${
                        isToday(day)
                          ? "bg-black ring-2 ring-offset-2 ring-black"
                          : isPast(day)
                          ? "bg-black"
                          : "border-[1.5px] border-black/40 bg-white"
                      }`}
                    />
                    <span
                      className={`mt-2 text-xs ${
                        isToday(day)
                          ? "font-bold text-black"
                          : isPast(day)
                          ? "text-black/60"
                          : "text-black/30"
                      }`}
                    >
                      {day}
                    </span>
                  </>
                ) : null}
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}

/* ── Month Dots ── */
function MonthDots({
  months,
  onMonthClick,
}: {
  months: string[];
  onMonthClick: (month: string) => void;
}) {
  return (
    <>
      <div className="absolute top-[26px] left-0 right-20 h-[2px] bg-black/40 z-0" />
      <div className="flex items-start gap-16 md:gap-28 z-10">
        {months.map((month, idx) => (
          <button
            key={month}
            onClick={() => onMonthClick(month)}
            className="flex flex-col items-center group outline-none"
            data-testid={`btn-month-${idx}`}
          >
            <div className="w-5 h-5 rounded-full bg-black transition-transform duration-300 group-hover:scale-150" />
            <span className="mt-4 text-base font-medium text-black/70 group-hover:text-black transition-colors duration-300 whitespace-nowrap">
              {month}
            </span>
          </button>
        ))}
      </div>
    </>
  );
}
